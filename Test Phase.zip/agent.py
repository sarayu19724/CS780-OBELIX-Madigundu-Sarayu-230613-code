import numpy as np
import torch
import torch.nn as nn
import os

ACTIONS = ["L45", "L22", "FW", "R22", "R45"]
class DQN(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.ReLU(),

            nn.Linear(128, 128),
            nn.ReLU(),

            nn.Linear(128, 128),   
            nn.ReLU(),

            nn.Linear(128, out_dim)
        )

    def forward(self, x):
        return self.net(x)

_model = None


def _load_model(obs_dim):
    global _model

    if _model is not None:
        return _model

    model = DQN(obs_dim, len(ACTIONS))

    weight_path = os.path.join(os.path.dirname(__file__), "weights.pth")

    if os.path.exists(weight_path):
        try:
            state = torch.load(weight_path, map_location="cpu")
            if isinstance(state, dict):
                if "state_dict" in state:
                    state = state["state_dict"]
                elif "model_state_dict" in state:
                    state = state["model_state_dict"]

            model.load_state_dict(state, strict=True)

        except Exception as e:
            print(f"[WARNING] Weight loading failed: {e}")

    else:
        print("[WARNING] weights.pth not found")

    model.eval()
    _model = model
    return model


@torch.no_grad()
def policy(obs: np.ndarray, rng=None):
    obs = np.asarray(obs, dtype=np.float32)
    if obs.ndim > 1:
        obs = obs.flatten()

    model = _load_model(len(obs))

    x = torch.from_numpy(obs).unsqueeze(0)

    try:
        q_values = model(x)
        action_idx = int(torch.argmax(q_values, dim=1).item())
    except Exception:
        action_idx = int(np.random.randint(len(ACTIONS)))

    return ACTIONS[action_idx]